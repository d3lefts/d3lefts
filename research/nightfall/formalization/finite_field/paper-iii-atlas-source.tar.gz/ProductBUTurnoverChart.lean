import Mathlib.Analysis.Calculus.InverseFunctionTheorem.ContDiff
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.LinearAlgebra.Dimension.Finrank

open scoped Topology ContDiff
namespace Nightfall.ProductBUTurnoverChart
noncomputable section
variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [NormedAddCommGroup F] [NormedSpace ℝ F]
  [FiniteDimensional ℝ F]

/-- A codimension-one surjection admits a scalar complementary coordinate,
without requiring the physical time derivative to be nonzero. -/
theorem exists_kernel_coordinate (D : E →L[ℝ] F)
    (hs : Function.Surjective D)
    (hd : Module.finrank ℝ E = Module.finrank ℝ F + 1) :
    ∃ l : E →L[ℝ] ℝ, ∃ e : E ≃L[ℝ] (ℝ × F),
      (e : E →L[ℝ] (ℝ × F)) = l.prod D := by
  let d := D.toLinearMap
  have hr : d.range = ⊤ := LinearMap.range_eq_top.mpr hs
  have hk := d.finrank_range_add_finrank_ker
  rw [hr, finrank_top, hd] at hk
  have hk1 : Module.finrank ℝ d.ker = 1 := by omega
  let k : d.ker ≃ₗ[ℝ] ℝ := LinearEquiv.ofFinrankEq _ _ (by simpa using hk1)
  obtain ⟨p, hp⟩ := LinearMap.exists_leftInverse_of_injective d.ker.subtype
    (LinearMap.ker_eq_bot.mpr Subtype.val_injective)
  let l : E →L[ℝ] ℝ := (k.toLinearMap.comp p).toContinuousLinearMap
  let q := l.prod D
  have hi : Function.Injective q := by
    apply (LinearMap.ker_eq_bot (f := q.toLinearMap)).mp
    rw [Submodule.eq_bot_iff]
    intro x hx
    change q x = 0 at hx
    have hl : l x = 0 := congrArg Prod.fst hx
    have hD : D x = 0 := congrArg Prod.snd hx
    let z : d.ker := ⟨x, hD⟩
    have hpz : p x = z := DFunLike.congr_fun hp z
    have hkl : k z = 0 := by
      change k (p x) = 0 at hl
      rwa [hpz] at hl
    have hz : z = 0 := k.injective (by simpa using hkl)
    exact congrArg Subtype.val hz
  have hdim : Module.finrank ℝ E = Module.finrank ℝ (ℝ × F) := by
    rw [Module.finrank_prod, Module.finrank_self, hd, Nat.add_comm]
  have hsur := (LinearMap.injective_iff_surjective_of_finrank_eq_finrank hdim (f := q.toLinearMap)).mp hi
  let e := (LinearEquiv.ofBijective q.toLinearMap ⟨hi, hsur⟩).toContinuousLinearEquiv
  exact ⟨l, e, rfl⟩

/-- Local inverse construction with a genuinely smooth inverse on its full
open target. The source can be restricted to any prescribed open set. -/
theorem smooth_ambient_chart [CompleteSpace E] {G : Type*}
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (Q : E → G) (hQ : ContDiff ℝ (∞ : ℕ∞ω) Q) (x : E)
    (e : E ≃L[ℝ] G) (hD : HasFDerivAt Q (e : E →L[ℝ] G) x)
    (S : Set E) (hS : IsOpen S) (hx : x ∈ S) :
    ∃ q : OpenPartialHomeomorph E G,
      x ∈ q.source ∧ q.source ⊆ S ∧
      (∀ z, q z = Q z) ∧
      ContDiffOn ℝ (∞ : ℕ∞ω) (q.symm : G → E) q.target := by
  have hstrict := hQ.contDiffAt.hasStrictFDerivAt' hD (by simp)
  let q₀ := hstrict.toOpenPartialHomeomorph Q
  let U : Set E := {z | (fderiv ℝ Q z).IsInvertible}
  have hU : IsOpen U := ContinuousLinearMap.isOpen_setOfPred_isInvertible.preimage
    (hQ.continuous_fderiv (by simp))
  have hxU : x ∈ U := by
    change (fderiv ℝ Q x).IsInvertible
    rw [hD.fderiv]
    exact ⟨e,rfl⟩
  let q := q₀.restr (U ∩ S)
  have hsource : q.source = q₀.source ∩ (U ∩ S) := by
    rw [OpenPartialHomeomorph.restr_source, (hU.inter hS).interior_eq]
  refine ⟨q, ?_, ?_, ?_, ?_⟩
  · rw [hsource]
    exact ⟨hstrict.mem_toOpenPartialHomeomorph_source, hxU, hx⟩
  · rw [hsource]
    exact fun z hz => hz.2.2
  · intro z
    rfl
  · intro y hy
    have hz := q.map_target hy
    rw [hsource] at hz
    obtain ⟨e', he'⟩ := hz.2.1
    have hder : HasFDerivAt (q : E → G) (e' : E →L[ℝ] G) (q.symm y) := by
      change HasFDerivAt Q _ _
      rw [he']
      exact (hQ.differentiable (by simp) _).hasFDerivAt
    exact (q.contDiffAt_symm hy hder hQ.contDiffAt).contDiffWithinAt

/-- Every regular codimension-one point admits a smooth ambient inverse
chart, including when the time coordinate has a turning point. On the
entire open chart, actual zeros correspond exactly to the horizontal axis. -/
theorem regular_point_ambient_chart [CompleteSpace E]
    (f : E → F) (hf : ContDiff ℝ (∞ : ℕ∞ω) f) (x : E)
    (hs : Function.Surjective (fderiv ℝ f x))
    (hd : Module.finrank ℝ E = Module.finrank ℝ F + 1)
    (S : Set E) (hS : IsOpen S) (hx : x ∈ S) :
    ∃ l : E →L[ℝ] ℝ, ∃ q : OpenPartialHomeomorph E (ℝ × F),
      x ∈ q.source ∧ q.source ⊆ S ∧
      (∀ z, q z = (l (z - x), f z)) ∧
      ContDiffOn ℝ (∞ : ℕ∞ω) (q.symm : ℝ × F → E) q.target ∧
      (∀ y ∈ q.target, f (q.symm y) = y.2) ∧
      (∀ z ∈ q.source, q.symm (l (z - x), f z) = z) := by
  obtain ⟨l,e,he⟩ := exists_kernel_coordinate (fderiv ℝ f x) hs hd
  let Q : E → ℝ × F := fun z => (l (z - x), f z)
  have hQ : ContDiff ℝ (∞ : ℕ∞ω) Q :=
    (l.contDiff.comp (contDiff_id.sub contDiff_const)).prodMk hf
  have hD : HasFDerivAt Q (e : E →L[ℝ] (ℝ × F)) x := by
    rw [he]
    exact ((l.hasFDerivAt).comp x ((hasFDerivAt_id x).sub_const x)).prodMk
      (hf.differentiable (by simp) x).hasFDerivAt
  obtain ⟨q,hxq,hsub,hq,hsm⟩ := smooth_ambient_chart Q hQ x e hD S hS hx
  refine ⟨l,q,hxq,hsub,hq,hsm,?_,?_⟩
  · intro y hy
    have h := q.right_inv hy
    rw [hq] at h
    exact congrArg Prod.snd h
  · intro z hz
    have h := q.left_inv hz
    rwa [hq] at h

#print axioms exists_kernel_coordinate
#print axioms smooth_ambient_chart
#print axioms regular_point_ambient_chart
end
end Nightfall.ProductBUTurnoverChart
