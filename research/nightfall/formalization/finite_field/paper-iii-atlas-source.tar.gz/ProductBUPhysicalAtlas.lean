import ProductBUTurnoverChart
import Mathlib.Geometry.Manifold.Instances.Icc
import Mathlib.Geometry.Manifold.IsManifold.InteriorBoundary
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

open scoped Topology ContDiff Manifold
open Manifold
namespace Nightfall.ProductBUPhysicalAtlas
open Nightfall.ProductBUTurnoverChart
noncomputable section
variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]

def physical (f : E → F) (t : E →L[ℝ] ℝ) : Set E :=
  {x | f x = 0 ∧ 0 ≤ t x ∧ t x ≤ 1}

/-- All chart data refer to the actual closed-time fiber, not to a new topology. -/
structure AxisData (Z : Set E) (t : E →L[ℝ] ℝ) where
  U : Set E
  V : Set ℝ
  openU : IsOpen U
  openV : IsOpen V
  a : E → ℝ
  b : ℝ → E
  smoothA : ContDiff ℝ (∞ : ℕ∞ω) a
  smoothB : ContDiffOn ℝ (∞ : ℕ∞ω) b V
  forward : ∀ x ∈ Z, x ∈ U → a x ∈ V ∧ 0 ≤ a x
  backward : ∀ y ∈ V, 0 ≤ y → b y ∈ Z ∧ b y ∈ U
  left : ∀ x ∈ Z, x ∈ U → b (a x) = x
  right : ∀ y ∈ V, 0 ≤ y → a (b y) = y
  boundary : ∀ x ∈ Z, x ∈ U → (a x = 0 ↔ t x = 0)

/-- Interior chart from a regular ambient derivative; no condition on dt along
its kernel. The exponential puts the entire chart in the positive half-line. -/
theorem interior_axis_data [FiniteDimensional ℝ E] [FiniteDimensional ℝ F] [CompleteSpace E]
    (f : E → F) (t : E →L[ℝ] ℝ) (hf : ContDiff ℝ (∞ : ℕ∞ω) f)
    (x : E) (hx : x ∈ physical f t) (ht : 0 < t x ∧ t x < 1)
    (hs : Function.Surjective (fderiv ℝ f x))
    (hd : Module.finrank ℝ E = Module.finrank ℝ F + 1) :
    ∃ C : AxisData (physical f t) t, x ∈ C.U := by
  let S : Set E := t ⁻¹' Set.Ioo 0 1
  have hS : IsOpen S := isOpen_Ioo.preimage t.continuous
  obtain ⟨l,q,hxq,hsub,hq,hsm,hr,hl⟩ := regular_point_ambient_chart f hf x hs hd S hS ht
  let V : Set ℝ := {y | 0 < y ∧ (Real.log y, (0 : F)) ∈ q.target}
  have hV : IsOpen V := by
    apply isOpen_iff_mem_nhds.mpr
    intro y hy
    have hlog : ContinuousAt (fun y : ℝ => (Real.log y, (0 : F))) y :=
      (Real.continuousAt_log (ne_of_gt hy.1)).prodMk continuousAt_const
    exact Filter.inter_mem (Ioi_mem_nhds hy.1) (hlog.preimage_mem_nhds (q.open_target.mem_nhds hy.2))
  let a : E → ℝ := fun z => Real.exp (l (z - x))
  let b : ℝ → E := fun y => q.symm (Real.log y, 0)
  have ha : ContDiff ℝ (∞ : ℕ∞ω) a := Real.contDiff_exp.comp
    (l.contDiff.comp (contDiff_id.sub contDiff_const))
  have hb : ContDiffOn ℝ (∞ : ℕ∞ω) b V := by
    apply hsm.comp
    · exact (Real.contDiffOn_log.mono (fun y (hy : y ∈ V) => ne_of_gt hy.1)).prodMk contDiffOn_const
    · exact fun y hy => hy.2
  refine ⟨⟨q.source,V,q.open_source,hV,a,b,ha,hb,?_,?_,?_,?_,?_⟩,hxq⟩
  · intro z hz hu
    refine ⟨⟨Real.exp_pos _,?_⟩, (Real.exp_pos _).le⟩
    have hm := q.map_source hu
    rw [hq] at hm
    simpa only [a,Real.log_exp,hz.1] using hm
  · intro y hy _
    have hm := q.map_target hy.2
    have htime := hsub hm
    exact ⟨⟨hr _ hy.2, htime.1.le, htime.2.le⟩,hm⟩
  · intro z hz hu
    change q.symm (Real.log (Real.exp (l (z-x))), 0) = z
    rw [Real.log_exp]
    simpa only [hz.1] using hl z hu
  · intro y hy _
    have h := q.right_inv hy.2
    rw [hq] at h
    change Real.exp (l (q.symm (Real.log y, 0) - x)) = y
    have hfst : l (q.symm (Real.log y, 0) - x) = Real.log y := congrArg Prod.fst h
    rw [hfst, Real.exp_log hy.1]
  · intro z hz hu
    have htime := hsub hu
    exact iff_of_false (ne_of_gt (Real.exp_pos _)) (ne_of_gt htime.1)

/-- At a transverse entrance the actual physical time is the boundary chart.
The inverse extends smoothly across time zero in the ambient open target. -/
theorem boundary_axis_data [FiniteDimensional ℝ E] [CompleteSpace E]
    (f : E → F) (t : E →L[ℝ] ℝ) (hf : ContDiff ℝ (∞ : ℕ∞ω) f)
    (x : E) (hx : x ∈ physical f t) (ht : t x = 0)
    (he : (t.prod (fderiv ℝ f x)).IsInvertible) :
    ∃ C : AxisData (physical f t) t, x ∈ C.U := by
  obtain ⟨e,he⟩ := he
  let Q : E → ℝ × F := fun z => (t z, f z)
  have hQ : ContDiff ℝ (∞ : ℕ∞ω) Q := t.contDiff.prodMk hf
  have hD : HasFDerivAt Q (e : E →L[ℝ] (ℝ × F)) x := by
    rw [he]
    exact t.hasFDerivAt.prodMk (hf.differentiable (by simp) x).hasFDerivAt
  let S : Set E := t ⁻¹' Set.Iio 1
  have hS : IsOpen S := isOpen_Iio.preimage t.continuous
  have hxS : x ∈ S := by change t x < 1; rw [ht]; norm_num
  obtain ⟨q,hxq,hsub,hq,hsm⟩ := smooth_ambient_chart Q hQ x e hD S hS hxS
  let V : Set ℝ := (fun y : ℝ => (y, (0 : F))) ⁻¹' q.target
  have hV : IsOpen V := q.open_target.preimage (continuous_id.prodMk continuous_const)
  let b : ℝ → E := fun y => q.symm (y, 0)
  have hb : ContDiffOn ℝ (∞ : ℕ∞ω) b V := hsm.comp
    (contDiffOn_id.prodMk contDiffOn_const) (fun y hy => hy)
  have hback : ∀ y ∈ V, Q (b y) = (y,0) := by
    intro y hy
    have h := q.right_inv hy
    rwa [hq] at h
  refine ⟨⟨q.source,V,q.open_source,hV,t,b,t.contDiff,hb,?_,?_,?_,?_,?_⟩,hxq⟩
  · intro z hz hu
    have hm := q.map_source hu
    rw [hq] at hm
    exact ⟨by simpa only [V, Set.mem_preimage, Q,hz.1] using hm, hz.2.1⟩
  · intro y hy hnon
    have hm := q.map_target hy
    have ht' : t (b y) = y := congrArg Prod.fst (hback y hy)
    have hf' : f (b y) = 0 := congrArg Prod.snd (hback y hy)
    exact ⟨⟨hf', by rwa [ht'], (hsub hm).le⟩,hm⟩
  · intro z hz hu
    have h := q.left_inv hu
    rw [hq] at h
    simpa only [Q,b,hz.1] using h
  · intro y hy _
    exact congrArg Prod.fst (hback y hy)
  · intros; rfl

/-- The unique coordinate of the one-dimensional Euclidean model. -/
def realCoord : EuclideanSpace ℝ (Fin 1) ≃L[ℝ] ℝ :=
  (EuclideanSpace.equiv (Fin 1) ℝ).trans (ContinuousLinearEquiv.funUnique (Fin 1) ℝ ℝ)

@[simp] theorem realCoord_apply (z : EuclideanSpace ℝ (Fin 1)) :
    realCoord z = z.ofLp 0 := rfl

def halfCoord (y : EuclideanHalfSpace 1) : ℝ := realCoord y.1

theorem halfCoord_nonneg (y : EuclideanHalfSpace 1) : 0 ≤ halfCoord y := y.2

def halfMk (r : ℝ) (hr : 0 ≤ r) : EuclideanHalfSpace 1 :=
  ⟨realCoord.symm r, by rw [← realCoord_apply, realCoord.apply_symm_apply]; exact hr⟩

@[simp] theorem halfCoord_halfMk (r : ℝ) (hr : 0 ≤ r) :
    halfCoord (halfMk r hr) = r := realCoord.apply_symm_apply r

theorem halfCoord_injective : Function.Injective halfCoord := fun x y h =>
  Subtype.ext (realCoord.injective h)

theorem continuous_halfCoord : Continuous halfCoord :=
  realCoord.continuous.comp continuous_subtype_val

namespace AxisData
variable {Z : Set E} {t : E →L[ℝ] ℝ} (C : AxisData Z t)

def chartForward (x : Z) : EuclideanHalfSpace 1 :=
  halfMk (max (C.a x) 0) (le_max_right _ _)

def chartBackward (x₀ : Z) (y : EuclideanHalfSpace 1) : Z := by
  classical
  exact
    if h : halfCoord y ∈ C.V then
      ⟨C.b (halfCoord y), (C.backward _ h (halfCoord_nonneg y)).1⟩
    else x₀

theorem forward_coord (x : Z) (hx : x.1 ∈ C.U) :
    halfCoord (C.chartForward x) = C.a x := by
  simp [chartForward, max_eq_left (C.forward x x.2 hx).2]

theorem backward_val (x₀ : Z) (y : EuclideanHalfSpace 1) (hy : halfCoord y ∈ C.V) :
    (C.chartBackward x₀ y).1 = C.b (halfCoord y) := by simp [chartBackward, hy]

def chart (x₀ : Z) : OpenPartialHomeomorph Z (EuclideanHalfSpace 1) where
  toFun := C.chartForward
  invFun := C.chartBackward x₀
  source := Subtype.val ⁻¹' C.U
  target := halfCoord ⁻¹' C.V
  map_source' := by
    intro x hx
    change halfCoord (C.chartForward x) ∈ C.V
    rw [C.forward_coord x hx]
    exact (C.forward x x.2 hx).1
  map_target' := by
    intro y hy
    change halfCoord y ∈ C.V at hy
    change (C.chartBackward x₀ y).1 ∈ C.U
    rw [C.backward_val x₀ y hy]
    exact (C.backward _ hy (halfCoord_nonneg y)).2
  left_inv' := by
    intro x hx
    apply Subtype.ext
    have h := (C.forward x x.2 hx).1
    have hc := C.forward_coord x hx
    rw [C.backward_val x₀ _ (hc ▸ h),hc,C.left x x.2 hx]
  right_inv' := by
    intro y hy
    change halfCoord y ∈ C.V at hy
    apply halfCoord_injective
    have hb := C.backward _ hy (halfCoord_nonneg y)
    have hval := C.backward_val x₀ y hy
    rw [C.forward_coord _ (hval ▸ hb.2),hval,C.right _ hy (halfCoord_nonneg y)]
  continuousOn_toFun := by
    apply Continuous.continuousOn
    exact (realCoord.symm.continuous.comp ((C.smoothA.continuous.comp continuous_subtype_val).max continuous_const)).subtype_mk _
  continuousOn_invFun := by
    rw [continuousOn_iff_continuous_domRestrict]
    let S : Set (EuclideanHalfSpace 1) := halfCoord ⁻¹' C.V
    have hbase : Continuous (fun y : S => C.b (halfCoord y.1)) :=
      C.smoothB.continuousOn.comp_continuous (continuous_halfCoord.comp continuous_subtype_val) (fun y => y.2)
    have heq : (fun y : S => C.chartBackward x₀ y.1) =
        (fun y : S => (⟨C.b (halfCoord y.1), (C.backward _ y.2 (halfCoord_nonneg y.1)).1⟩ : Z)) := by
      funext y; apply Subtype.ext; exact C.backward_val _ _ y.2
    change Continuous (fun y : S => C.chartBackward x₀ y.1)
    rw [heq]
    exact hbase.subtype_mk _
  open_source := C.openU.preimage continuous_subtype_val
  open_target := C.openV.preimage continuous_halfCoord

/-- The transition is the restriction of the smooth ambient composition
of one chart's inverse and the other's forward coordinate. -/
theorem compatible (D : AxisData Z t) (x₀ x₁ : Z) :
    ContDiffOn ℝ (∞ : ℕ∞ω)
      ((𝓡∂ 1) ∘ ⇑((C.chart x₀).symm ≫ₕ D.chart x₁) ∘ (𝓡∂ 1).symm)
      ((𝓡∂ 1).symm ⁻¹' ((C.chart x₀).symm ≫ₕ D.chart x₁).source ∩ Set.range (𝓡∂ 1)) := by
  let I := 𝓡∂ 1
  let S := I.symm ⁻¹' ((C.chart x₀).symm ≫ₕ D.chart x₁).source ∩ Set.range I
  have hc : ∀ z ∈ S, halfCoord (I.symm z) = realCoord z := by
    intro z hz
    have h := I.right_inv hz.2
    change (I.symm z).1 = z at h
    exact congrArg realCoord h
  have hm : ∀ z ∈ S, realCoord z ∈ C.V := by
    intro z hz
    have h := hz.1
    change I.symm z ∈ ((C.chart x₀).symm ≫ₕ D.chart x₁).source at h
    rw [OpenPartialHomeomorph.trans_source] at h
    have h' : halfCoord (I.symm z) ∈ C.V := h.1
    rwa [hc z hz] at h'
  have hcomp : ContDiffOn ℝ (∞ : ℕ∞ω) (fun z => realCoord.symm (D.a (C.b (realCoord z)))) S :=
    realCoord.symm.contDiff.contDiffOn.comp
      (D.smoothA.contDiffOn.comp (C.smoothB.comp realCoord.contDiff.contDiffOn hm) (fun _ _ => Set.mem_univ _))
      (fun _ _ => Set.mem_univ _)
  apply hcomp.congr
  intro z hz
  have h := hz.1
  change I.symm z ∈ ((C.chart x₀).symm ≫ₕ D.chart x₁).source at h
  rw [OpenPartialHomeomorph.trans_source] at h
  have hv : halfCoord (I.symm z) ∈ C.V := h.1
  have hu : (C.chartBackward x₀ (I.symm z)).1 ∈ D.U := h.2
  have hb := C.backward_val x₀ (I.symm z) hv
  change (D.chartForward (C.chartBackward x₀ (I.symm z))).1 = _
  apply realCoord.injective
  change halfCoord (D.chartForward (C.chartBackward x₀ (I.symm z))) = _
  rw [D.forward_coord _ hu, hb, hc z hz, realCoord.apply_symm_apply]

end AxisData

/-- A covering collection of axis charts builds a charted space on the
original zero-fiber subtype. -/
def physicalChartedSpace {Z : Set E} {t : E →L[ℝ] ℝ}
    (C : Z → AxisData Z t) (hC : ∀ x : Z, x.1 ∈ (C x).U) :
    ChartedSpace (EuclideanHalfSpace 1) Z where
  atlas := Set.range (fun x : Z => (C x).chart x)
  chartAt := fun x => (C x).chart x
  mem_chart_source := hC
  chart_mem_atlas := fun x => ⟨x,rfl⟩

theorem physicalChartedSpace_smooth {Z : Set E} {t : E →L[ℝ] ℝ}
    (C : Z → AxisData Z t) (hC : ∀ x : Z, x.1 ∈ (C x).U) :
    @IsManifold ℝ _ _ _ _ _ _ (𝓡∂ 1) (∞ : ℕ∞ω) Z _ (physicalChartedSpace C hC) := by
  letI : ChartedSpace (EuclideanHalfSpace 1) Z := physicalChartedSpace C hC
  apply isManifold_of_contDiffOn
  intro e e' he he'
  obtain ⟨x,rfl⟩ := he
  obtain ⟨y,rfl⟩ := he'
  exact (C x).compatible (C y) x y

theorem halfspace_frontier : frontier (Set.range (𝓡∂ 1)) = realCoord ⁻¹' {0} := by
  have hrange : Set.range (𝓡∂ 1) = realCoord ⁻¹' Set.Ici 0 := by
    ext z
    constructor
    · rintro ⟨y,rfl⟩
      exact y.2
    · intro hz
      exact ⟨⟨z,hz⟩,rfl⟩
  rw [hrange]
  change frontier (realCoord.toHomeomorph ⁻¹' Set.Ici 0) = _
  rw [← realCoord.toHomeomorph.preimage_frontier, frontier_Ici]
  rfl

theorem physicalChartedSpace_boundary {Z : Set E} {t : E →L[ℝ] ℝ}
    (C : Z → AxisData Z t) (hC : ∀ x : Z, x.1 ∈ (C x).U) :
    letI : ChartedSpace (EuclideanHalfSpace 1) Z := physicalChartedSpace C hC
    (𝓡∂ 1).boundary Z = {x : Z | t x.1 = 0} := by
  letI : ChartedSpace (EuclideanHalfSpace 1) Z := physicalChartedSpace C hC
  ext x
  change ((C x).chartForward x).1 ∈ frontier (Set.range (𝓡∂ 1)) ↔ t x.1 = 0
  rw [halfspace_frontier]
  change halfCoord ((C x).chartForward x) = 0 ↔ t x.1 = 0
  rw [(C x).forward_coord x (hC x)]
  exact (C x).boundary x x.2 (hC x)

/-- The actual closed-time zero fiber is a smooth one-manifold with boundary
exactly at time zero. Only the codimension-one regular derivative, entrance
transversality and absence of exit zeros are needed. No chart or boundary
identification is assumed. -/
theorem physical_regular_manifold [FiniteDimensional ℝ E] [FiniteDimensional ℝ F] [CompleteSpace E]
    (f : E → F) (t : E →L[ℝ] ℝ) (hf : ContDiff ℝ (∞ : ℕ∞ω) f)
    (hd : Module.finrank ℝ E = Module.finrank ℝ F + 1)
    (hreg : ∀ x ∈ physical f t, Function.Surjective (fderiv ℝ f x))
    (hentry : ∀ x ∈ physical f t, t x = 0 → (t.prod (fderiv ℝ f x)).IsInvertible)
    (hnoexit : ∀ x ∈ physical f t, t x ≠ 1) :
    ∃ cs : ChartedSpace (EuclideanHalfSpace 1) (physical f t),
      letI := cs
      IsManifold (𝓡∂ 1) (∞ : ℕ∞ω) (physical f t) ∧
      (𝓡∂ 1).boundary (physical f t) = {x : physical f t | t x.1 = 0} := by
  classical
  have hlocal : ∀ x : physical f t, ∃ C : AxisData (physical f t) t, x.1 ∈ C.U := by
    intro x
    by_cases hz : t x.1 = 0
    · exact boundary_axis_data f t hf x.1 x.2 hz (hentry x.1 x.2 hz)
    · have hpos : 0 < t x.1 := lt_of_le_of_ne x.2.2.1 (Ne.symm hz)
      have hlt : t x.1 < 1 := lt_of_le_of_ne x.2.2.2 (hnoexit x.1 x.2)
      exact interior_axis_data f t hf x.1 x.2 ⟨hpos,hlt⟩ (hreg x.1 x.2) hd
  choose C hC using hlocal
  exact ⟨physicalChartedSpace C hC,physicalChartedSpace_smooth C hC,physicalChartedSpace_boundary C hC⟩

#print axioms interior_axis_data
#print axioms AxisData.compatible
#print axioms physicalChartedSpace_smooth
#print axioms physicalChartedSpace_boundary
#print axioms physical_regular_manifold
#print axioms boundary_axis_data
end
end Nightfall.ProductBUPhysicalAtlas
